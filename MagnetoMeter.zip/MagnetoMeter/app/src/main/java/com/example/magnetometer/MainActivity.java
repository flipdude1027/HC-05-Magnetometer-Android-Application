/* So this is it. This is the one and only MagnetoMeter. This is the app that rules them all!

   Anyway, I'm going to start this app by copy-pasting this other guys code:
   https://stackoverflow.com/questions/13450406/how-to-receive-serial-data-using-android-bluetooth.
   I literally have no idea how to set up Bluetooth and stuff. Instead of the bottom-up approach I
   usually take, I'll be modifying someone else's existing code. I'm no genius -- I'll give credit
   where credit is due.

   After copying the XML code, I needed to clean up this file. I guess with this version of Android
   Studio, you no longer have to cast screen components when using findViewById().

   So I only needed to change two things in this code: (1) The delimiter, (2) Name of Bluetooth
   Device. The app WORKS! I can get the data from the Arduino as well as send data TO the Arduino!
   I put the app onto my phone and the data is displayed onto it. It's AMAZING! The only problem
   is that the SEMICOLON delimiter of the data is removed. For now, I don't see this is a huge
   problem. It might be down the line, but, hey, I got this to work!

   This app gives me functionality to open and close the connection. Data is only sent after the
   connection is made. There is no buffer of the data even when the magnetometer continues to run.
   I tested it by closing the connection, putting a magnet next to the magnetometer, then reopening
   the connection. The next values I got were high, meaning that all data is real time.

   What this App does:
   * Finds a Bluetooth connection (OPEN)
   * Connects to a Bluetooth connection (OPEN/CLOSE)
   * Reads data from the Bluetooth
   * Sends data to the Bluetooth (SEND)

   Connecting to a device is hardcoded into the program, meaning, at this point in time, the program
   can only connect to the device that is hardcoded in. The program reads data that is separated by
   a delimiter, so you need to send data in that format (ex: 1232131,123123124,54363645;).

   Things I need to do:
   * Find out where strings are saved
   * Update UI
   * Structure the data
   * Save the data
   * Process/display data real time
 */

package com.example.magnetometer;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity
{
    TextView myLabel;
    EditText myTextbox;
    BluetoothAdapter mBluetoothAdapter;
    BluetoothSocket mmSocket;
    BluetoothDevice mmDevice;
    OutputStream mmOutputStream;
    InputStream mmInputStream;
    Thread workerThread;
    byte[] readBuffer;
    int readBufferPosition;
    int counter;
    volatile boolean stopWorker;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        // Housekeeping
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize basic components
        Button openButton = findViewById(R.id.open);
        Button sendButton = findViewById(R.id.send);
        Button closeButton = findViewById(R.id.close);
        myLabel = findViewById(R.id.label);
        myTextbox = findViewById(R.id.entry);

        //Open Button: Finds and opens Bluetooth connection
        openButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    findBT();
                    openBT();
                }
                catch (IOException ex) {
                    System.out.println("EXCEPTION!");
                } // Needs catch because findBT()/openBT() throws
            }
        });

        //Send Button:
        sendButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    sendData();
                }
                catch (IOException ex) {
                    System.out.println("EXCEPTION!");
                }
            }
        });

        //Close button
        closeButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    closeBT();
                }
                catch (IOException ex) {
                    System.out.println("EXCEPTION!");
                }
            }
        });
    }

    void findBT()
    {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null)
        {
            myLabel.setText("No bluetooth adapter available"); // Apparently not an error; can ignore
        }

        if(!mBluetoothAdapter.isEnabled())
        {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, 0);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                if(device.getName().equals("HC-05")) // Change this to YOUR Bluetooth
                {
                    mmDevice = device;
                    break;
                }
            }
        }
        myLabel.setText("Bluetooth Device Found");
    }

    void openBT() throws IOException
    {
        UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
        mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid); // Create connection
        mmSocket.connect(); // Connect
        mmOutputStream = mmSocket.getOutputStream(); // Output is what is sent FROM Android
        mmInputStream = mmSocket.getInputStream(); // Input is what is sent TO Android

        // Listens for data, lol
        beginListenForData();

        myLabel.setText("Bluetooth Opened"); // Not an error
    }

    void beginListenForData()
    {
        final Handler handler = new Handler();
        final byte delimiter = 59; //This is the ASCII code for a SEMICOLON

        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];

        // Thread
        workerThread = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopWorker)
                {
                    try
                    {
                        int bytesAvailable = mmInputStream.available(); // Check if something sent to Android via Bluetooth (process is automatic once device connected)
                        if(bytesAvailable > 0)
                        {
                            byte[] packetBytes = new byte[bytesAvailable];
                            mmInputStream.read(packetBytes); // Reads data byte by byte
                            for(int i=0;i<bytesAvailable;i++)
                            {
                                byte b = packetBytes[i];
                                if(b == delimiter) // Once the delimiter (SEMICOLON) is found
                                {
                                    byte[] encodedBytes = new byte[readBufferPosition];
                                    System.arraycopy(readBuffer, 0, encodedBytes, 0, encodedBytes.length);
                                    final String data = new String(encodedBytes, "US-ASCII");
                                    readBufferPosition = 0;

                                    handler.post(new Runnable()
                                    {
                                        public void run()
                                        {
                                            myLabel.setText(data);
                                        }
                                    });
                                }
                                else
                                {
                                    readBuffer[readBufferPosition++] = b;
                                }
                            }
                        }
                    }
                    catch (IOException ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }

    void sendData() throws IOException
    {
        String msg = myTextbox.getText().toString();
        msg += "\n";
        mmOutputStream.write(msg.getBytes()); // To Bluetooth; this process is automatic
        myLabel.setText("Data Sent");
    }

    void closeBT() throws IOException
    {
        stopWorker = true;
        mmOutputStream.close();
        mmInputStream.close();
        mmSocket.close();
        myLabel.setText("Bluetooth Closed");
    }
}